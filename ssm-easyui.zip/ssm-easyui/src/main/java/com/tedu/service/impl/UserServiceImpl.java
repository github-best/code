package com.tedu.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tedu.dao.UserMapper;
import com.tedu.pojo.User;
import com.tedu.service.UserService;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserMapper userDao;
  
	@Override
	public List<User> selectUser(String userName, int startRows, int pageSize) {
		return userDao.selectUsers(userName,startRows,pageSize);
	}
	

	@Override
	public int getRowCount() {
		return userDao.getRowCount();
	}


	@Override
	public int addUser(User user) {
		return userDao.addUser(user);
	}


	@Override
	public int updateUserById(User user) {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public User selectUsersById(User user) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public int deleteUserById(Integer id) {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public List<User> findAll() {
		
		return userDao.findAll();
	}






}
