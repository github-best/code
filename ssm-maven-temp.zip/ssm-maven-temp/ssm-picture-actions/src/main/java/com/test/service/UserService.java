package com.test.service;

import java.util.List;

import com.test.pojo.User;

public interface UserService {

	List<User> selectUser(String names, int startRows, int pageSize);

	int getRowCount();

	int addUser(User user);

	int updateUserById(User user);

	User selectUsersById(User user);

	int deleteUserById(Integer id);

	List<User> findAll();

}
