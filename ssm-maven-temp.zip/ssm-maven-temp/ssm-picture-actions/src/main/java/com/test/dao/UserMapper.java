package com.test.dao;

import java.util.List;

import com.test.pojo.User;

public interface UserMapper {//


	int getRowCount();

	List<User> selectUsers(String userName, int startRows, int pageSize);

	int addUser(User user);

	List<User> findAll();

}
