package com.test.controller;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.test.pojo.User;
import com.test.result.Result;
import com.test.service.UserService;
@Controller
public class UserController {

	@Autowired
	private UserService userService;

	
	
	@RequestMapping("/test")
	@ResponseBody
	public Result test(HttpServletResponse response,Integer page,Integer rows){
		
		
		System.out.println("============hello=================");
	/*	
	 * datagrid在向页面发送起请求时，默认传递page、和rows
	 * 两个参数到后端请求分页
	 *  page 当前页码
		rows 传当前页行数，页面大小
		System.out.println("======page======"+page);
		System.out.println("===== rows======="+ rows);
		        ======page======1
				===== rows=======10*/
		
		PageHelper.startPage(page, rows);
		
		List<User> list = userService.findAll();
		PageInfo<User> pageInfo = new PageInfo<>(list);

		//表的总记录数
		int total = (int)pageInfo.getTotal();
		Result result = new Result();
		result.setTotal(total);
		result.setRows(list);
		
		
	/*	for (User user : list) {
			System.out.println(user);
		}*/
/*	System.out.println(result);
	Result [total=12, rows=Page{count=true, pageNum=1, pageSize=10, startRow=0, 
			endRow=10, total=12, pages=2, reasonable=true, pageSizeZero=false}]*/

		
        
		return result;
	}
	
}

